package com.example.budgetapp.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey

@Entity(
    tableName = "receipt_items",
    foreignKeys = [
        ForeignKey(
            entity = Receipt::class,
            parentColumns = ["id"],
            childColumns = ["receiptId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Product::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.SET_NULL
        )
    ]
)
data class ReceiptItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val receiptId: Long,
    val productId: Long? = null, // Koppling till befintlig produkt (kan vara null för nya produkter)
    val productName: String, // Produktnamn som visades på kvittot
    val quantity: Double,
    val unitPrice: Double,
    val totalPrice: Double,
    val unit: String = "st", // st, kg, g, l, ml, etc.
    val discount: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)