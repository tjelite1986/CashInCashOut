package com.example.budgetapp.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.budgetapp.ProductListActivity
import com.example.budgetapp.StoreManagerActivity
import com.example.budgetapp.data.BackupManager
import com.example.budgetapp.database.BudgetDatabase
import com.example.budgetapp.databinding.FragmentSettingsBinding
import kotlinx.coroutines.launch

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var backupManager: BackupManager
    
    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri?.let { 
            lifecycleScope.launch {
                backupManager.exportToFile(it).fold(
                    onSuccess = { message ->
                        Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
                    },
                    onFailure = { error ->
                        Toast.makeText(requireContext(), "Export misslyckades: ${error.message}", Toast.LENGTH_LONG).show()
                    }
                )
            }
        }
    }
    
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { 
            showImportConfirmationDialog {
                lifecycleScope.launch {
                    backupManager.importFromFile(it).fold(
                        onSuccess = { message ->
                            Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
                        },
                        onFailure = { error ->
                            Toast.makeText(requireContext(), "Import misslyckades: ${error.message}", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        try {
            initializeBackupManager()
            setupUI()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    private fun initializeBackupManager() {
        val database = BudgetDatabase.getDatabase(requireContext())
        backupManager = BackupManager(requireContext(), database)
    }

    private fun setupUI() {
        binding.textTitle.text = "Inställningar"
        binding.textDescription.text = "Här kan du anpassa appen efter dina behov"
        
        setupClickListeners()
    }
    
    private fun setupClickListeners() {
        binding.cardProductManagement.setOnClickListener {
            val intent = Intent(requireContext(), ProductListActivity::class.java)
            startActivity(intent)
        }
        
        binding.cardStoreManagement.setOnClickListener {
            val intent = Intent(requireContext(), StoreManagerActivity::class.java)
            startActivity(intent)
        }
        
        binding.layoutCurrency.setOnClickListener {
            showCurrencyDialog()
        }
        
        binding.layoutTheme.setOnClickListener {
            showThemeDialog()
        }
        
        binding.switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            val message = if (isChecked) "Notifikationer aktiverade" else "Notifikationer inaktiverade"
            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
        }
        
        binding.layoutExportData.setOnClickListener {
            exportData()
        }
        
        binding.layoutImportData.setOnClickListener {
            importData()
        }
    }
    
    private fun showCurrencyDialog() {
        val currencies = arrayOf("SEK", "EUR", "USD", "NOK", "DKK")
        val currentCurrency = binding.textCurrency.text.toString()
        val currentIndex = currencies.indexOf(currentCurrency)
        
        AlertDialog.Builder(requireContext())
            .setTitle("Välj valuta")
            .setSingleChoiceItems(currencies, currentIndex) { dialog, which ->
                binding.textCurrency.text = currencies[which]
                Toast.makeText(requireContext(), "Valuta ändrad till ${currencies[which]}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Avbryt", null)
            .show()
    }
    
    private fun showThemeDialog() {
        val themes = arrayOf("Ljust", "Mörkt", "Systemets val")
        val currentTheme = binding.textTheme.text.toString()
        val currentIndex = themes.indexOf(currentTheme)
        
        AlertDialog.Builder(requireContext())
            .setTitle("Välj tema")
            .setSingleChoiceItems(themes, currentIndex) { dialog, which ->
                binding.textTheme.text = themes[which]
                Toast.makeText(requireContext(), "Tema ändrat till ${themes[which]}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Avbryt", null)
            .show()
    }
    
    private fun exportData() {
        val fileName = backupManager.generateBackupFileName()
        exportLauncher.launch(fileName)
    }
    
    private fun importData() {
        importLauncher.launch(arrayOf("application/json", "text/plain"))
    }
    
    private fun showImportConfirmationDialog(onConfirmed: () -> Unit) {
        AlertDialog.Builder(requireContext())
            .setTitle("Importera data")
            .setMessage("Detta kommer att lägga till all data från backup-filen till din befintliga data. Vill du fortsätta?")
            .setPositiveButton("Ja, importera") { _, _ -> onConfirmed() }
            .setNegativeButton("Avbryt", null)
            .setIcon(android.R.drawable.ic_dialog_alert)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}